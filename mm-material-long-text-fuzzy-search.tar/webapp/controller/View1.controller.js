sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/SearchField",
  "sap/ui/table/Column",
  "sap/m/Label",
  "sap/m/Text",
  "sap/m/ColumnListItem",
  "sap/m/Token",
  "sap/m/Column",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  'sap/m/MessageToast',
  "sap/ui/model/type/String",
  'sap/m/MessageItem'
], (Controller, SearchField, UIColumn, Label, Text, ColumnListItem, Token,  MColumn, Filter, FilterOperator, MessageToast, MessageItem, TypeString) => {
  "use strict";

  return Controller.extend("com.wl.mm.material.controller.View1", {
      onInit() {
        // Initialize multi-input fields
          this._oMultiInputMaterialType = this.byId("multipleInputWithSuggestionsmaterialTyp");
          this._oMultiInputMaterialKeyword = this.byId("multipleInputWithSuggestionsmaterial");
          this._oMultiInputFuzzyScore = this.byId("multipleInputWithSuggestionsfuzzy");
          this._oMultiInputMaximumNoofHits = this.byId("multipleInputWithSuggestionsmaxhits");
        },
        
        onMaterialTypeValueHelpRequested: function () {
          // Load the fragment for Material Type value help
            this.loadFragment({
              name: "com.wl.mm.material.fragment.Material"
            }).then(function (oDialog) {
              var oFilterBar = oDialog.getFilterBar(), oColumnMaterialType, oColumnlanguage, oColumnmaterial;
              this._oVHD = oDialog;
              this.getView().addDependent(oDialog);
     
              
     
              // Set key fields for filtering in the Define Conditions Tab
              oDialog.setRangeKeyFields([{
                label: "{i18n>valuehelp_MaterialType}",
                key: "MaterialType",
                type: "string",
                typeInstance: new TypeString({}, {
                  maxLength: 6
                })
              }]);
     
               oDialog.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                  // Bind rows to the ODataModel and add columns
                  oTable.bindAggregation("rows", {
                    path: "/I_MaterialTypeText",
                    events: {
                      dataReceived: function () {
                        oDialog.update();
                      }
                    }
                  });
                  oColumnMaterialType = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_MaterialType}" }), template: new Text({ wrapping: false, text: "{MaterialType}" }) });
                  oColumnMaterialType.data({
                    fieldName: "MaterialType"
                  });
                  oColumnlanguage = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_langu}" }), template: new Text({ wrapping: false, text: "{Language}" }) });
                  oColumnlanguage.data({
                    fieldName: "Language"
                  });
     
                  oColumnmaterial = new UIColumn({ label: new Label({ text: "{i18n>valuehelp_Material}" }), template: new Text({ wrapping: false, text: "{MaterialTypeName}" }) });
                  oColumnmaterial.data({
                    fieldName: "MaterialTypeName"
                  });
                  oTable.addColumn(oColumnMaterialType);
                  oTable.addColumn(oColumnlanguage);
                  oTable.addColumn(oColumnmaterial);
                }
     
                // For Mobile the default table is sap.m.Table
                if (oTable.bindItems) {
                  // Bind items to the ODataModel and add columns
                  oTable.bindAggregation("items", {
                    path: "/I_MaterialTypeText",
                    template: new ColumnListItem({
                      cells: [new Label({ text: "{MaterialType}" }), new Label({ text: "{Language}" }), new Label({ text: "{MaterialTypeName}" })]
                    }),
                    events: {
                      dataReceived: function () {
                        oDialog.update();
                      }
                    }
                  });
                  oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_MaterialType}" }) }));
                  oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_langu}" }) }));
                  oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>valuehelp_Material}" }) }));
                }
                oDialog.update();
              }.bind(this));

              oDialog.open();
            }.bind(this));
          },
    
          onValueHelpWithSuggestionsMaterialTypeOkPress: function (oEvent) {
             // Handle OK press event for Material Type value help
            var aTokens = oEvent.getParameter("tokens");
            if(aTokens && aTokens.length>0){
              this._oMultiInputMaterialType.setValue(aTokens[0].getKey());
            }
            
            this._oVHD.close();
          },
          // Handle Cancel press event for Material Type value help
          onValueHelpWithSuggestionsMaterialTypeCancelPress: function () {
            this._oVHD.close();
          },
          // Destroy the value help dialog after closing
          onValueHelpWithSuggestionsAfterClose: function () {
            this._oVHD.destroy();
          },
          // Execute search with the provided filter values
         onExecutePress: function () {
          var 
          sMaterialKeyword = this._oMultiInputMaterialKeyword.getValue(),
          sMaterialType = this._oMultiInputMaterialType.getValue(),
          sMaterialFuzzyScore = this._oMultiInputFuzzyScore.getValue(),
          sMaterialMaximumNo = this._oMultiInputMaximumNoofHits.getValue(),
          aFilter = [];

          // Validation: Ensure the Material Keyword field is filled
    if  (!sMaterialKeyword) {
      MessageToast.show("Please fill in the Mandatory field.");
      return; // Stop execution if the validation fails
    }
  
  
        if (sMaterialKeyword) {
          aFilter.push(new Filter({
            path: "Material",
            operator: FilterOperator.EQ,
            value1: sMaterialKeyword.toUpperCase()
          }));
        }
        if (sMaterialType) {
          aFilter.push(new Filter({
            path: "ZMTART",
            operator: FilterOperator.EQ,
            value1: sMaterialType.toUpperCase()
          }));
        }
        if (sMaterialFuzzyScore) {
          aFilter.push(new Filter({
            path: "Fuzzy_Score",
            operator: FilterOperator.EQ,
            value1: sMaterialFuzzyScore.toUpperCase()
          }));
        }
        if (sMaterialMaximumNo) {
          aFilter.push(new Filter({
            path: "MAXRECORDS",
            operator: FilterOperator.EQ,
            value1: sMaterialMaximumNo.toUpperCase()
          }));
        }
    
        this.getOwnerComponent().getModel("local").setProperty("/filterData", aFilter);
        this.fnReset();
        },
        fnReset: function (oEvent) {
          // Reset the SmartTable with the new entity set and rebind the table
          var oReportTable = this.getView().byId("_IDGenSmartTable");
          oReportTable.setEntitySet("ZMM_CDS_I_FUZZY_SERACH");
          oReportTable.rebindTable();
        },
        onBeforeRebindTable: function (oEvent) {
          // Add filters before rebinding the table
          var binding = oEvent.getParameter("bindingParams");
          var aFilter = this.getView().getModel("local").getProperty("/filterData");
          if (aFilter)
            aFilter.forEach(function (el) {
              binding.filters.push(el);
            });
        },
      
      })
       
       
    });
  