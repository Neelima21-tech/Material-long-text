/* global QUnit */

sap.ui.require(["com/wl/mm/material/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
