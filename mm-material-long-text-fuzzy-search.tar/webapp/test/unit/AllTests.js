sap.ui.define([
	"comwlmm/material/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
